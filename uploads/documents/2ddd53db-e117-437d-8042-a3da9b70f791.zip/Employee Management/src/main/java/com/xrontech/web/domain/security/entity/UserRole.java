package com.xrontech.web.domain.security.entity;

public enum UserRole {
    ADMIN,
    USER
}
